# 插件开发 SDK 示例（com.example.plugin-sdk）

这是 Libra-Nextgen 插件的**全能力演示**（活文档）：把插件作者能用的所有能力与
可选项都做成可运行示例。可直接导入（zip），也可作为新插件的最小起点模板。

## 目录结构

```
com.example.plugin-sdk/
├── meta.json               # 插件契约（字段与可选项见页面“总览”页签）
├── module/                 # Agent 端模块（script 通道，Rhai 无需编译）
│   └── plugin_sdk.rhai     #   多平台 API + #if 条件编译 + 自描述 manifest
├── service/                # 服务端逻辑（C# 脚本，随包分发）
│   └── main.cs             #   11 个函数：动态参数/时间/签名/状态/HTTP/文件/数组…
├── page/                   # 前端页面源码（分发用，需重建前端）
│   └── index.tsx           #   5 个页签：总览 / Agent 模块 / 服务端脚本 / 前端 API / HeroUI
├── data/                   # 随包分发的数据文件（脚本 file 函数可读）
│   └── demo.json
└── README.md
```

## 能力矩阵

| 层 | 载体 | 能力 |
|---|---|---|
| Agent 端 | `module/plugin_sdk.rhai` | fs 读写/列目录/存在性、proc 列表、env、whoami、log；Windows：cmd/powershell/reg_*/ipconfig/wmic/tasklist；Linux：shell/bash/uname/ip_route/ss/hostname/dns；`#if(WINDOWS)/#elif(LINUX)` 解析期条件编译 |
| 服务端 | `service/main.cs` | echo(动态参数) / now(格式化) / bkn(签名) / state(跨调用状态) / ip(无 CORS 请求) / http(通用请求+请求头) / file(读包内文件) / list(数组) / table(对象数组) / fail(错误契约) / manifest(自描述目录) |
| 前端 | `page/index.tsx` | usePluginHost(selectedAgent/dispatchTask/subscribeOutput/lastOutput)、api client、插件管理、插件市场(localStorage 1h 缓存)、HeroUI 全组件画廊 |

## 导入与运行

1. 控制台 → 插件管理 → 上传本 zip（或从 Git / 市场导入）。
2. 启用插件后：
   - **Agent 模块**：前端页选择 capability 点执行 → `dispatchTask` 下发 → Agent
     内存执行 Rhai → 结果经 WS 实时推送。
   - **服务端脚本**：`POST /api/plugin/com.example.plugin-sdk/<函数名>`，
     body 任意 JSON 作为脚本参数 `p`（dynamic）；返回 `{ok,data}`，抛异常返回
     `{ok:false,error}`。函数目录可调 `manifest` 实时获取。
3. 前端页面是**源码分发**：`page/index.tsx` 需放入前端仓库
   `src/webapp/src/plugins/com.example.plugin-sdk/index.tsx` 并重建前端
   （`import.meta.glob` 构建期收集）。本仓库已内置该页面。

## 发布到插件市场

把打好的 `plugin-sdk.zip` 提交到 Libra-Plugins 仓库根目录，CI（或本地
`pwsh build-index.ps1`）会重新生成 `index.json`，市场即可安装。
